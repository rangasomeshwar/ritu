package com.co;

import java.io.File;
import java.io.IOException;

public class Bintotiff {

	public static void main(String[] args) {

		String src = "C:\\Users\\894850\\Downloads\\_FORMS";

		File folder = new File(src);

		try {
			processSubFolder(folder);
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	private static void processSubFolder(File folder) throws IOException {

		long start = System.currentTimeMillis();
		for (File file : folder.listFiles()) {

			if (file.isDirectory()) {

				processSubFolder(file); // Calls same method again.

			} else {

				int count = 0;
				String fileExtension = ".bin";
				for (File f1 : file.getParentFile().listFiles()) {
					if (f1.getName().endsWith(fileExtension)) {

						String outputFile = "C:\\Users\\894850\\Downloads\\SAMPLE";

						File file1 = new File(outputFile + "\\" + f1.getParentFile().getName());

						if (!file1.exists())
							file1.mkdir();

						String in = f1.getAbsolutePath();
						String out = file1 + "\\" + count + ".tif";

						File output = new File(out);
						File input = new File(in);

						input.renameTo(output);
						count++;

						long end = System.currentTimeMillis();
						System.out.println("Copied in " + (end - start) + " ms");

					}

				}
			}

		}

	}
}
